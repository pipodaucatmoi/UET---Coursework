package bai51;

public class Main {

    public static void useString() {
        long startTime = System.currentTimeMillis();
        String str = "";
        for (int i = 0; i < 100000; i++) {
            str += "Hello";
        }
        long endTime = System.currentTimeMillis();
        System.out.println("1. Thời gian chạy của String: " + (endTime - startTime) + " ms");
    }

    public static void useStringBuffer() {
        long startTime = System.currentTimeMillis();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < 100000; i++) {
            sb.append("Hello");
        }
        long endTime = System.currentTimeMillis();
        System.out.println("2. Thời gian chạy của StringBuffer: " + (endTime - startTime) + " ms");
    }

    public static void contentAnalysis(String text) {
        System.out.println("\n--- 3. Phân tích văn bản ---");
        // Đếm số lượng câu dựa vào dấu chấm, chấm hỏi, chấm than
        String[] sentences = text.split("[.?!]+");
        System.out.println("Số lượng câu: " + sentences.length);

        // Tìm và thay thế
        String replacedText = text.replace("Java", "Python");
        System.out.println("Văn bản sau khi Replace (Java -> Python):\n" + replacedText);
    }

    public static void main(String[] args) {
        System.out.println("Đang đo lường hiệu năng, vui lòng đợi...");
        useString();
        useStringBuffer();

        String document = "Hello world. This is a Java program! Do you like Java? Yes, Java is great.";
        contentAnalysis(document);
    }
}