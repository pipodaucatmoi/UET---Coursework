package task47;
interface Operation<T>{
    void execute(T a, T b);
}