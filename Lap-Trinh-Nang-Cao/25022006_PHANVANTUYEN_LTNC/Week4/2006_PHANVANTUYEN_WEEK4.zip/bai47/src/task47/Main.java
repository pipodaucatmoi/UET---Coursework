package task47;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.List;

public class Main{
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = Integer.parseInt(sc.nextLine());
        List<Student> students = new ArrayList<>();

        for (int i = 0; i < n; i++) {
            String input = sc.nextLine();
            String chia[] = input.split("\\s+");
            String id = chia[0];
            String name = chia[1];
            Double gpa = Double.parseDouble(chia[2]);
            students.add(new Student(id, name, gpa));
        }
        System.out.println();
        students.removeIf(student -> student.getGpa() < 5.0);
        System.out.println("After removing GPA < 5.0: ");
        students.forEach(student -> System.out.println(student));
        System.out.println();
        students.sort((s1, s2) -> s1.getName().compareTo(s2.getName()));
        System.out.println("After sorting by name: ");
        students.forEach(student -> System.out.println(student));
        sc.close();
    }
}