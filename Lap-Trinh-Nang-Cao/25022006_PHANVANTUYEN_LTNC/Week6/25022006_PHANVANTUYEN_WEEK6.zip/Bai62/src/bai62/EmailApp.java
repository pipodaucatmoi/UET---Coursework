package bai62;

class EmailApp extends NotificationApp {
    @Override
    public Notification createNotification() {
        return new EmailNotification(); // Lớp con quyết định đẻ ra Email
    }
}
